import { CreateProductForm } from "./_components/CreateProductForm";

export const metadata = {
  title: "Products",
};
export default function CreateProductsPage() {
  return (
    <>
      Create Product
      <CreateProductForm />
    </>
  );
}
